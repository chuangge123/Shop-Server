create
    definer = root@localhost procedure save_address(IN p_username varchar(30), IN p_phone varchar(30),
                                                    IN p_address varchar(100), IN p_uid int, IN p_def int)
BEGIN

	if  p_def = 1 
		then  update t_address set def = 0 where uid = p_uid;
	end if;

	insert into t_address (username,phone,address,uid,def) values(p_username,p_phone,p_address,p_uid,p_def);
end;

